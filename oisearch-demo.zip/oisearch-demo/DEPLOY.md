# Oi-suite — demo online zetten

Statische site met drie pagina's die naar elkaar linken via het "Oi-apps"-menu:

- `over.html` ..... landingspagina / het verhaal ("je hebt een keuze")
- `index.html` .... Oisearch (zoekmachine)
- `oimail.html` ... Oimail (mailclient-preview)

Geen build, geen server nodig.

## Snelste weg (± 2 min)
- **Vercel drag & drop:** vercel.com → Add New… → Project → sleep deze map (of de zip) → Deploy.
- **CLI:** `npm i -g vercel` → `vercel && vercel --prod`.
- **Jouw stack:** GitHub-repo → Vercel importeren (framework preset **Other**) → Deploy.

Tip: wil je `over.html` als voordeur? Zet in Vercel een redirect van `/` naar
`/over.html`, of hernoem de bestanden naar wens.

## Privacy — wat er wél en niet gebeurt
Deze site is bewust tracker-vrij:
- **Geen Google Fonts, geen favicon-tracker, geen Google Maps.**
- Lettertypes staan lokaal (zie hieronder). Kaarten lopen via **OpenStreetMap**.
- Autocomplete gebruikt **DuckDuckGo**; het kennispaneel gebruikt **Wikipedia**.
- De standaard-fallbackzoekmachine is **DuckDuckGo**.
- **Google wordt alleen gebruikt als jij zelf** een Custom Search-sleutel invult
  (voor volledige webresultaten). Laat je die leeg, dan raakt de pagina Google niet.
- In de preview blijft alle Oimail-data **lokaal in de browser**; niets gaat naar een server.

## Lettertypes zelf hosten (voor het exacte uiterlijk)
De pagina's laden geen fonts van Google. Voor het echte Fredoka/Nunito-uiterlijk:
1. Download de variabele **.woff2** van https://fontsource.org/fonts/fredoka en
   https://fontsource.org/fonts/nunito (of Google Fonts → converteer naar woff2).
2. Zet ze neer als `fonts/Fredoka.woff2` en `fonts/Nunito.woff2`.
Zonder die bestanden werkt alles gewoon met een afgerond systeemlettertype.
(Zie `fonts/LEESMIJ.txt`.)

## Oisearch: live zoekresultaten (gratis, ± 5 min)
Werkt meteen dankzij het Wikipedia-kennispaneel. Voor volledige web- en
afbeeldingsresultaten: maak een gratis Google Custom Search-sleutel + cx aan
(programmablesearchengine.google.com en developers.google.com/custom-search) en
zet ze onder ⚙️ Instellingen, of vast in `index.html` bij `const HARDCODED`.

## Oimail: van preview naar échte mailbox
De preview is een volledige front-end (lezen, sturen, mappen, zoeken) zonder
mailserver. Om het echt te maken (kan niet in een los HTML-bestand):
1. **Alleen versturen:** een serverless-functie `/api/send` die via Resend/
   Postmark/Mailgun mailt; zet die URL onder ⚙️ Instellingen → "Verzend-endpoint".
   De API-sleutel blijft op de server — nooit in de pagina.
2. **Ook ontvangen:** inkomende mail via Cloudflare Email Routing of een
   inbound-webhook naar een serverless-functie + database (bv. Vercel KV/Postgres).

Voor het Europese/privacy-verhaal: kies EU-hosting (Vercel EU-regio, of een
Europese provider zoals Hetzner/Scaleway) en een EU-mailprovider.

## Domein & social preview (later)
Vercel → Settings → Domains → domein toevoegen + DNS zetten (net als oibase.nl).
Vervang daarna de placeholder-URL's `https://oisearch.nl/` en `https://oimail.nl/`
in de HTML, `robots.txt` en de manifests door je echte adressen.

## Bestanden
- `over.html`, `index.html`, `oimail.html` .. de drie pagina's
- `fonts/` ......... zelf-gehoste lettertypes (voeg je woff2 toe)
- `og.png`, `oimail-og.png` .. social-previews
- `icon-*`, `oimail-icon-*`, `apple-touch-icon*` .. app-iconen
- `manifest.webmanifest`, `oimail-manifest.webmanifest`
- `robots.txt`, `vercel.json`
